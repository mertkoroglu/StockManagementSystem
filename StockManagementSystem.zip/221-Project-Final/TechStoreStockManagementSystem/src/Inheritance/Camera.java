package Inheritance;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class Camera extends Device{
    private int photoResolution;

    public Camera(int photoResolution, int barcodeNo, String color, String brand, String model, int memory) {
        super(barcodeNo, color, brand, model, memory);
        this.photoResolution = photoResolution;
    }

    public int getPhotoResolution() {
        return photoResolution;
    }
    
    @Override
    public double computePrice() {
        double fee = 1500;
        switch (photoResolution) {
            case 2:
                fee += 500;
                break;
            case 4:
                fee += 1500;
                break;
            case 8:
                fee += 2500;
                break;
            default:
                break;
        }
      
      this.price = fee;
      return price;
    }
    
    @Override
    public String toString(){
        return "---CAMERA---" + super.toString() + "\nPhoto Resolution: " + photoResolution + "K\n" + "Price: " + computePrice() + "$";
    }
    
}

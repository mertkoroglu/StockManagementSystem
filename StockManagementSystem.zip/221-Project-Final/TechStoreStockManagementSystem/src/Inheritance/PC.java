package Inheritance;


import Has_A.GraphicsCard;
import Interface.PCInterface;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class PC extends Device implements PCInterface{
    private String PCtype;
    private ArrayList<GraphicsCard> GC = new ArrayList<>();
    private GraphicsCard GC1 = null;
    Device D;

    public PC(int barcodeNo, String color, String brand, String model, int memory, String PCtype, ArrayList<GraphicsCard> GC,String GCbrand, String version) {
        super(barcodeNo, color, brand, model, memory);
        this.PCtype = PCtype;
        this.GC = GC;
        GC1 = new GraphicsCard(GCbrand,  version);
        GC.add(new GraphicsCard(GCbrand,  version));
        
    }

    @Override
    public double computePrice() {
        double fee= 3000;
        if(PCtype.equalsIgnoreCase("Laptop"))
            fee += 500;
        else if(PCtype.equalsIgnoreCase("Desktop"))
            fee += 1000;
        this.price = fee;
        return price;
    }
    
    public String toString(){
        return "--PC--" + super.toString() + "\nPC type: " + PCtype  + GC1.toString() + "\nPrice: " + computePrice() + "$" + totalGraphicsCard();
    }

    @Override
    public String totalGraphicsCard() {
        String out = "";
        int totalNvidia = 0;
        int totalAMD = 0;
        for(int i = 0; i < GC.size(); i++){
            if(GC.get(i).getBrand().equals("NVIDIA"))
                totalNvidia++;
            else if(GC.get(i).getBrand().equals("AMD"))
                totalAMD++;
        }
      
        out = "\nTotal number of graphics cards: \nNVIDIA: " + totalNvidia + "\nAMD: " + totalAMD;
        return out;
         }
    
}

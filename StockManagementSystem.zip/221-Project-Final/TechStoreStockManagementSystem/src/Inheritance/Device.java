package Inheritance;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public abstract class Device {
    protected int barcodeNo;
    protected double price;
    protected String color;
    protected String brand;
    protected String model;
    protected int memory;

    public Device(int barcodeNo, String color, String brand, String model, int memory) {
        this.barcodeNo = barcodeNo;
        this.color = color;
        this.brand = brand;
        this.model = model;
        this.memory = memory;
    }

    
    public double getPrice() {
        return price;
    }
    
    
    public void setPrice(double price) {
        this.price = price;
    }

    public int getBarcodeNo() {
        return barcodeNo;
    }
    
        
    public static boolean checkBarcode(int barcode, ArrayList<Device> list){
        for(int i = 0; i< list.size(); i++){
        if(list.get(i).getBarcodeNo() == barcode) 
            return true;
        }
            return false;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }
 
    public abstract double computePrice();
    
    public String toString(){
     return "\nBarcode No: " + barcodeNo + 
            "\nBrand: " + brand +
            "\nModel: " + model +
            "\nColor: " + color +
            "\nMemory: " + memory + " GB";
             }


}

package Inheritance;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class Phone extends Device{
    private String OperatingSystem;
    private int ScreenWidth;

    public Phone(String OperatingSystem, int ScreenWidth, int barcodeNo, String color, String brand, String model, int memory) {
        super(barcodeNo, color, brand, model, memory);
        this.OperatingSystem = OperatingSystem;
        this.ScreenWidth = ScreenWidth;
    }

    public String getOperatingSystem() {
        return OperatingSystem;
    }

    public int getScreenWidth() {
        return ScreenWidth;
    }
    
    @Override
    public String toString(){
        return "--PHONE--" + super.toString() +
                "\nOperating System: " + OperatingSystem +
                "\nScreen Width: " + ScreenWidth + " inch" +
                "\nPrice: " + computePrice() + "$";
    }
    
    @Override
    public double computePrice() {
      double fee = 2500;
       
      if(ScreenWidth < 4)
           fee += 1000;
       else if(ScreenWidth >4 && ScreenWidth < 7){
           fee += 1200;
       }
       else if(ScreenWidth > 7 && ScreenWidth < 9){
           fee += 1500;
       }
       this.price = fee;
       
    return price;
    }
    
}

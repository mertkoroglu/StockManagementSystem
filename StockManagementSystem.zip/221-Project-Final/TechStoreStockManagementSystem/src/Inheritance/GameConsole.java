package Inheritance;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class GameConsole extends Device{
    private String DiskDriver;

    public GameConsole(int barcodeNo, String color, String brand, String model, int memory, String DiskDriver) {
        super(barcodeNo, color, brand, model, memory);
        this.DiskDriver = DiskDriver;
    }

    @Override
    public double computePrice() {
        double fee = 2000;
        if(DiskDriver.equalsIgnoreCase("Yes")){
            fee += 100;
        }
        this.price = fee;
        return price;
    }
    
    @Override
    public String toString(){
        return "---GAME CONSOLE---" + super.toString() + "\nDisk Driver: " + DiskDriver + "\nPrice: " + computePrice() + "$";
    }
    
}

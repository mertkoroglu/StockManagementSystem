package SystemClassAndMain;


import GUI.DisplayFrame;
import GUI.MainFrame;
import GUI.RemoveFrame;
import GUI.SearchFrame;
import Has_A.GraphicsCard;
import GUI.ShoppingCartFrame;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class DeviceMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
           ArrayList<GraphicsCard> GC = new ArrayList<>();
           
        
        DeviceSys.addDevice("PC", 101, "Grey", "MSI", "Leopard", 64, -1, "", "", -1, "Laptop", GC, "AMD", "200");
        DeviceSys.addDevice("PC", 102, "Blue", "Monster", "Abra", 32, -1, "", "", 6, "Desktop", GC,"NVIDIA", "3070");
        DeviceSys.addDevice("PC", 103, "White", "Lenovo", "T009", 45, -1, "", "", 6, "Desktop", GC, "AMD", "3070");
        DeviceSys.addDevice("PC", 104, "Black", "Casper", "U90", 12, -1, "", "", 6, "Laptop", GC, "NVIDIA", "3070");
        DeviceSys.addDevice("Camera", 105, "Blue", "Canon", "U712", 108, 2, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("Phone", 106, "Black", "Oppo", "E80", 70, -1, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("GameConsole", 107, "Black", "Sony", "PlayStation 4", 64, -1, "Yes", "", 6, "", GC, "", "");
        DeviceSys.addDevice("Phone", 108, "White", "Apple", "IPhone 11 Pro Max", 12, -1, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("Camera", 109, "White", "Nikon", "TT", 33, 4, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("Camera", 110, "Black", "Sony", "L79", 44, 8, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("Phone", 111, "Grey", "Samsung", "S20+", 64, -1, "", "", 6, "", GC, "", "");
        DeviceSys.addDevice("PC", 112, "grey", "Monster", "Tulpar", 64, -1, "", "", 6, "Laptop", GC, "NVIDIA", "3070");

      
       MainFrame M = new MainFrame();
       M.setVisible(true);
     
    }
    
}

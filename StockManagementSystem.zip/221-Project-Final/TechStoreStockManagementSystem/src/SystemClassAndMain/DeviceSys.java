package SystemClassAndMain;


import Has_A.GraphicsCard;
import Inheritance.Camera;
import Inheritance.PC;
import Inheritance.GameConsole;
import Inheritance.Phone;
import Inheritance.Device;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class DeviceSys {
    private static ArrayList<Device> list = new ArrayList<>();
    
    public static Device SearchDevice(int barcode){
        for(int i = 0; i<list.size(); i++){
            if(list.get(i).getBarcodeNo() == barcode)
                return list.get(i);
        }
        return null;
    }

    
    public static String addDevice(String userEntry, int barcodeNo, String color, String brand, String model, int memory, int photoResolution, String DiskDriver, String OperatingSystem, int ScreenWidth, String PCtype, ArrayList<GraphicsCard> GC, String GCbrand, String version){
        Phone P;
        PC PC1;
        GameConsole GC1;
        Camera C;
        String flag = "yes";
        String out = "";
                
        for(int i = 0; i < list.size(); i++){
            if(list.get(i).getModel().equalsIgnoreCase(model) && list.get(i).getBrand().equalsIgnoreCase(brand))
                flag = "no";
        }
        
         if (!Device.checkBarcode(barcodeNo, list)) {
             if(!flag.equalsIgnoreCase("no")){
                if (userEntry.equalsIgnoreCase("Phone")) {
                    P = new Phone(OperatingSystem, ScreenWidth, barcodeNo, color, brand, model, memory);
                    list.add(P);
                    return P.toString();
                }
                 else if(userEntry.equalsIgnoreCase("PC")){
                    PC1 = new PC(barcodeNo, color, brand, model, memory, PCtype, GC, GCbrand, version);
                    list.add(PC1);
                     return PC1.toString();
                }else if(userEntry.equalsIgnoreCase("GameConsole")){
                    GC1 = new GameConsole(barcodeNo, color, brand, model, memory, DiskDriver);
                    list.add(GC1);
                    return GC1.toString();
                }else if(userEntry.equalsIgnoreCase("Camera")){
                    C = new Camera(photoResolution, barcodeNo, color, brand, model, memory);
                    list.add(C);
                    return C.toString();                    
                }
             } 
            return out = "---Device with the same brand and model,\n already exists in the stock!---";
         }
        
        return out = "---Barcode Already Exists---";

    }
    
    public static String RemoveDevice(int barcode){
        Device D;
        for(int i = 0; i< list.size(); i++){
        if(list.get(i).getBarcodeNo() == barcode) { 
            String out = list.get(i).toString();
            list.remove(i);
            return out + "\n\n----Device Removed----";
        }
        
        }
        return "---Barcode Not Found in the Stock---";
    }
    
    public static String display(){
        Device temp;
        String out = "";
        for (int i = 0; i < list.size(); i++) {
            temp = (Device) list.get(i);
            out += temp.toString() + "\n\n";
        }
        
        return out;
    }
    
    public static String DisplayEachStock(String userOp){
        String out = "";
        int total = 0;
        double price = 0;
        switch(userOp){
            case("Phone"):
                for(Device dv : list){
                    if(dv instanceof Phone){
                        out += dv.toString() + "\n\n";
                        total++;
                        price += dv.getPrice();
                    }
                }
            break;
            case("GameConsole"):
                for(Device dv : list){
                    if(dv instanceof GameConsole){
                        out += dv.toString() + "\n\n";
                        total++;
                        price += dv.getPrice();

                    }
                }
            break;
            case("Camera"):
                for(Device dv : list){
                    if(dv instanceof Camera){
                        out += dv.toString() + "\n\n";
                        total++;
                        price += dv.getPrice();

                    }
                }
            break;
            case("PC"):
                for(Device dv : list){
                    if(dv instanceof PC){
                        out += dv.toString() + "\n\n";
                        total++;
                        price += dv.getPrice();

                    }
                }
            break;
        }
        
        out += "There Are " + total + " " + userOp + " in Stock with the total price of " + price + "$\n\n";
        
        return out;
    }
    
    public static String ShoppingCart(int value, String choice, ArrayList<Device> array){
        String out = "";
        int temp = 0;
        double total = 0;
        Scanner inp = new Scanner(System.in);
        Device dev;
        
        
    if(!list.isEmpty()){
        if(Device.checkBarcode(value, list)){
            dev = SearchDevice(value);
            array.add(dev);
        }
           
       if(choice.equalsIgnoreCase("add")){
        if(!array.isEmpty()){
            for(int i = 0; i < array.size(); i++){
                out += "\n" + array.get(i).toString()+ "\n" ;
            }
        }
       }
       else if(choice.equalsIgnoreCase("buy")){
                for(int i = 0; i < array.size(); i++){
                             RemoveDevice(array.get(i).getBarcodeNo());
                             total += array.get(i).getPrice();
                        }
                array.clear();
                out = "---Purchase Successful---\n---Items you bought are removed from store's stock---\n---Total Payment is " + total + "$ ---" ;
            }
        else if(choice.equalsIgnoreCase("clear")){
                array.clear();
                out = "\n---Items are not bought---";
            }
        else
                out = "\n---Invalid Input! System shut down---";
        }
    else
         out = "---Stocks are empty, you cannot buy products---";
   return out;
}
}

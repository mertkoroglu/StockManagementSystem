package Has_A;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kenan Köroğlu
 */
public class GraphicsCard {
    private String Brand;
    private String Version;

    public GraphicsCard(String Brand, String Version) {
        this.Brand = Brand;
        this.Version = Version;
    }

    public String getBrand() {
        return Brand;
    }

    public String getVersion() {
        return Version;
    }
    
    @Override
    public String toString(){
        return "\nBrand: " + Brand + 
               "\nVersion: " + Version ;
    }
    
}
